(() => {
  const ASSETS = window.NUBI_ASSETS || {};
  const VARIANTS = window.NUBI_VARIANTS || [];

  const fallbackColors = [
    {key:'claro', name:'Azul Claro', hex:'#a9d8ec', price:14.07},
    {key:'oscuro', name:'Azul Oscuro', hex:'#1c3f66', price:14.37},
    {key:'rojo', name:'Rojo', hex:'#b23b3b', price:14.97}
  ];

  function money(cents) {
    return (Number(cents || 0) / 100).toLocaleString('es-ES', {
      minimumFractionDigits: 2, maximumFractionDigits: 2
    }) + ' €';
  }

  function variantForColor(key) {
    const color = fallbackColors.find(c => c.key === key);
    if (!VARIANTS.length) return null;
    const needle = color?.name?.toLowerCase() || '';
    return VARIANTS.find(v => (v.options || []).some(o => String(o).toLowerCase() === needle))
      || VARIANTS.find(v => (v.title || '').toLowerCase().includes(needle))
      || VARIANTS.find(v => v.available !== false)
      || VARIANTS[0];
  }

  const colors = fallbackColors.map(c => {
    const v = variantForColor(c.key);
    return {...c, variant: v, price: v ? Number(v.price) : c.price};
  });

  let currentColor = 'rojo';
  let galleryIndex = 0;
  let qty = 1;
  let cart = null;

  const $ = id => document.getElementById(id);

  function gallery() {
    return [ASSETS[currentColor], ASSETS.ropa, ASSETS.sofas, ASSETS.coche].filter(Boolean);
  }

  function renderColors() {
    const el = $('colors');
    if (!el) return;
    el.innerHTML = colors.map(c => `
      <button type="button" class="color-card ${c.key === currentColor ? 'active' : ''}" data-key="${c.key}">
        <div class="swatch" style="background:${c.hex}"></div>
        <div class="cname">${c.name}</div>
        <div class="cprice">${money(c.variant ? c.variant.price : Math.round(c.price * 100))}</div>
      </button>`).join('');

    el.querySelectorAll('.color-card').forEach(btn => btn.addEventListener('click', () => {
      currentColor = btn.dataset.key;
      galleryIndex = 0;
      renderColors();
      renderGallery();
      updatePrice();
    }));
  }

  function renderGallery() {
    const imgs = gallery();
    if (!$('mainImg') || !imgs.length) return;
    $('mainImg').src = imgs[galleryIndex] || imgs[0];
    $('galCount').textContent = `${galleryIndex + 1} / ${imgs.length}`;
    const th = $('thumbs');
    th.innerHTML = imgs.map((src, i) => `
      <button type="button" class="thumb ${i === galleryIndex ? 'active' : ''}" data-i="${i}">
        <img src="${src}" alt="">
      </button>`).join('');
    th.querySelectorAll('.thumb').forEach(b => b.addEventListener('click', () => {
      galleryIndex = Number(b.dataset.i);
      renderGallery();
    }));
  }

  function updatePrice() {
    const c = colors.find(x => x.key === currentColor) || colors[0];
    if (!c) return;
    $('colorName').textContent = c.name;
    const unit = c.variant ? Number(c.variant.price) : Math.round(c.price * 100);
    $('price').textContent = money(unit);
    $('addPrice').textContent = money(unit * qty);
  }

  function openDrawer() {
    $('overlay').classList.add('show');
    $('drawer').classList.add('show');
  }

  function closeDrawer() {
    $('overlay').classList.remove('show');
    $('drawer').classList.remove('show');
  }

  async function refreshCart() {
    try {
      const res = await fetch('/cart.js', {headers:{Accept:'application/json'}});
      cart = await res.json();
      renderCart();
    } catch (e) {
      console.error(e);
    }
  }

  function renderCart() {
    const badge = $('cartCount');
    const item = $('cartItem');
    const empty = $('emptyMsg');
    const sub = $('subtotal');

    if (!cart || !cart.items?.length) {
      badge.style.display = 'none';
      item.style.display = 'none';
      empty.style.display = 'block';
      sub.textContent = money(0);
      return;
    }

    const line = cart.items[0];
    badge.style.display = 'flex';
    badge.textContent = cart.item_count;
    item.style.display = 'flex';
    empty.style.display = 'none';
    $('ciImg').src = line.image || ASSETS[currentColor];
    $('ciMeta').textContent = `${line.variant_title || line.product_title} · ${money(line.final_price)}`;
    $('ciQty').textContent = line.quantity;
    $('ciPrice').textContent = money(line.final_line_price);
    sub.textContent = money(cart.total_price);
  }

  async function addToCart() {
    const c = colors.find(x => x.key === currentColor) || colors[0];
    const variantId = c?.variant?.id;
    if (!variantId) {
      alert('Selecciona el producto en el editor de Shopify y crea sus variantes antes de comprar.');
      return;
    }

    const res = await fetch('/cart/add.js', {
      method:'POST',
      headers:{'Content-Type':'application/json', Accept:'application/json'},
      body: JSON.stringify({items:[{id:variantId, quantity:qty}]})
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      alert(err.description || 'No se pudo añadir el producto al carrito.');
      return;
    }

    await refreshCart();
    openDrawer();
  }

  async function changeCart(delta) {
    if (!cart?.items?.length) return;
    const line = cart.items[0];
    const quantity = Math.max(0, line.quantity + delta);
    const res = await fetch('/cart/change.js', {
      method:'POST',
      headers:{'Content-Type':'application/json', Accept:'application/json'},
      body: JSON.stringify({id:line.key, quantity})
    });
    if (res.ok) {
      cart = await res.json();
      renderCart();
    }
  }

  $('galPrev')?.addEventListener('click', () => {
    const n = gallery().length;
    galleryIndex = (galleryIndex - 1 + n) % n;
    renderGallery();
  });

  $('galNext')?.addEventListener('click', () => {
    const n = gallery().length;
    galleryIndex = (galleryIndex + 1) % n;
    renderGallery();
  });

  $('qtyMinus')?.addEventListener('click', () => {
    if (qty > 1) {
      qty--;
      $('qtyVal').textContent = qty;
      updatePrice();
    }
  });

  $('qtyPlus')?.addEventListener('click', () => {
    qty++;
    $('qtyVal').textContent = qty;
    updatePrice();
  });

  $('cartOpen')?.addEventListener('click', async () => {
    await refreshCart();
    openDrawer();
  });
  $('drawerClose')?.addEventListener('click', closeDrawer);
  $('overlay')?.addEventListener('click', closeDrawer);
  $('continueShopping')?.addEventListener('click', closeDrawer);
  $('addCart')?.addEventListener('click', addToCart);
  $('ciMinus')?.addEventListener('click', () => changeCart(-1));
  $('ciPlus')?.addEventListener('click', () => changeCart(1));
  $('checkout-btn')?.addEventListener('click', () => window.location.href = '/checkout');
  document.querySelector('.checkout-btn')?.addEventListener('click', () => window.location.href = '/checkout');

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.querySelector(`.tab-panel[data-panel="${btn.dataset.tab}"]`)?.classList.add('active');
    });
  });

  document.querySelectorAll('.tab-panel img').forEach(img => {
    const key = img.closest('.tab-panel')?.dataset.panel;
    if (ASSETS[key]) img.src = ASSETS[key];
  });
  document.querySelector('.tab-btn[data-tab="ropa"]')?.classList.add('active');
  document.querySelector('.tab-panel[data-panel="ropa"]')?.classList.add('active');

  document.querySelectorAll('.faq-item').forEach(item => {
    item.querySelector('.faq-q')?.addEventListener('click', () => {
      const wasOpen = item.classList.contains('open');
      document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));
      if (!wasOpen) item.classList.add('open');
    });
  });

  renderColors();
  renderGallery();
  updatePrice();
  refreshCart();
})();
