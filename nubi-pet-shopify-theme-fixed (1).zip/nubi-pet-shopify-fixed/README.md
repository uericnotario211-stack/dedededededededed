# NUBI PET — Shopify Theme

Tema Shopify convertido desde el HTML original.

## Estructura
- `layout/theme.liquid` — estructura global.
- `templates/index.json` — página de inicio.
- `templates/product.json` — plantilla de producto.
- `sections/main-product.liquid` — página NUBI PET.
- `assets/nubi-pet.css` — estilos.
- `assets/nubi-pet.js` — galería, variantes y carrito Ajax.
- `assets/*.webp` — imágenes extraídas del HTML original.
- `config/` y `locales/` — configuración mínima del tema.

## Antes de publicar
1. Sube esta carpeta como tema a Shopify/GitHub.
2. En el editor del tema, abre la sección `NUBI PET — Página de producto`.
3. Selecciona el producto real de Shopify.
4. Comprueba que las variantes/color del producto coinciden con `Azul Claro`, `Azul Oscuro` y `Rojo` si quieres que el selector de colores las detecte automáticamente.
5. Publica el tema cuando hayas comprobado carrito y checkout.

El HTML original usaba un carrito simulado. Esta versión conecta `Añadir al carrito` con el carrito real de Shopify y mantiene la apariencia general.

## Nota sobre el editor de Shopify
Si el editor abre inicialmente en "Página 404", eso significa que la URL de vista previa actual no existe; no significa que la home esté rota. Este paquete incluye `templates/404.json` para que la plantilla 404 también sea editable. En el selector superior del editor, cambia a "Página de inicio" para ver la home o a "Productos > Producto predeterminado" para ver el producto.
